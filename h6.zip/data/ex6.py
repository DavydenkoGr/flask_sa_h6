def main():
    global_init(input())
    db_sess = create_session()
    for colonist in db_sess.query(User).filter(User.address == 'module_1',
                                               User.speciality.notilike('%engineer%'),
                                               User.position.notilike('%engineer%')):
        print(colonist.id)


if __name__ == '__main__':
    main()